
from django.http import HttpResponse
from .models import  Pregunta
from django.shortcuts import  render,get_object_or_404
def index(request):
    listaPreguntas = Pregunta.objects.order_by("fecha")[:]
    context = {"lista_preguntas": listaPreguntas}
    return render(request,"encuesta/index.html", context)

def ver_pregunta(request, id_pregunta):
    #get_object_or_404 es exactamente lo mismo que si hiciéramos una try/catch
    pregunta = get_object_or_404(Pregunta,pk=id_pregunta)
    return render(request, "encuesta/verpregunta.html",{"pregunta":pregunta})

def ver_resultado(request, id_pregunta):
    response = "Está viendo los resultados de pregunta  %s."
    return HttpResponse(response % id_pregunta)

def votar(request, id_pregunta):
    return HttpResponse("Estás votando en pregunta %s." % id_pregunta)

