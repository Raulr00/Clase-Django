from django.contrib import admin
from .models import  Pregunta
admin.site.register(Pregunta)
