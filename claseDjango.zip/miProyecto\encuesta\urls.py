from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("<int:id_pregunta>/",views.ver_pregunta,name="preguntas"),
    path("<int:id_pregunta>/resultados/", views.ver_resultado, name="resultados"),
    path("<int:id_pregunta>/voto/", views.votar, name="votar"),
]


